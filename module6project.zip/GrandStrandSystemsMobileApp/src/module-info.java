/**
 * 
 */
/**
 * 
 */
module GrandStrandSystemsMobileApp {
	requires org.junit.jupiter.api;
}